import { z } from 'zod';

export const CHATBOT_CONTEXT_CHANGED = 'CHATBOT_CONTEXT_CHANGED' as const;

export const DataClassificationSchema = z.enum(['public', 'internal', 'confidential', 'restricted']);

export const ChatbotContextEventSchema = z.object({
  eventVersion: z.literal('1.0'),
  sourceMfe: z.string().min(1),
  lob: z.string().min(1),
  contextType: z.string().min(1),
  contextId: z.string().min(1),
  contextSummary: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  classification: DataClassificationSchema,
  permissions: z
    .object({
      canViewDetails: z.boolean().default(false),
      canTriggerWorkflow: z.boolean().default(false)
    })
    .optional(),
  ttlSeconds: z.number().int().positive().max(3600).default(900),
  timestamp: z.string().datetime(),
  correlationId: z.string().min(1)
});

export type ChatbotContextEvent = z.infer<typeof ChatbotContextEventSchema>;

export const ChatMessageRequestSchema = z.object({
  message: z.string().min(1).max(4000),
  conversationId: z.string().min(1),
  context: ChatbotContextEventSchema.optional()
});

export type ChatMessageRequest = z.infer<typeof ChatMessageRequestSchema>;

export type SseEvent =
  | { event: 'metadata'; data: { correlationId: string; conversationId: string } }
  | { event: 'token'; data: { text: string } }
  | { event: 'policy_block'; data: { reason: string } }
  | { event: 'error'; data: { message: string } }
  | { event: 'done'; data: { finishReason: 'stop' | 'blocked' | 'error' } };
