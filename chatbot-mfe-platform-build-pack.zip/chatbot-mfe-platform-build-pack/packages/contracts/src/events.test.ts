import { describe, expect, it } from 'vitest';
import { ChatbotContextEventSchema } from './events';

describe('ChatbotContextEventSchema', () => {
  it('accepts safe event payload', () => {
    const parsed = ChatbotContextEventSchema.parse({
      eventVersion: '1.0',
      sourceMfe: 'PaymentsMFE',
      lob: 'Payments',
      contextType: 'payment_record_selected',
      contextId: 'PAY-1001',
      contextSummary: { status: 'Failed' },
      classification: 'confidential',
      ttlSeconds: 900,
      timestamp: new Date().toISOString(),
      correlationId: 'ctx_123'
    });
    expect(parsed.contextId).toBe('PAY-1001');
  });
});
