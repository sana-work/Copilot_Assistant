import HtmlWebpackPlugin from 'html-webpack-plugin';
import webpack from 'webpack';
const { ModuleFederationPlugin } = webpack.container;

export default {
  entry: './src/index.ts',
  mode: 'development',
  devtool: 'source-map',
  resolve: { extensions: ['.tsx', '.ts', '.js'] },
  module: { rules: [{ test: /\.tsx?$/, loader: 'ts-loader', exclude: /node_modules/ }] },
  plugins: [
    new ModuleFederationPlugin({
      name: 'chatbotMfe',
      filename: 'remoteEntry.js',
      exposes: { './App': './src/App' },
      shared: { react: { singleton: true }, 'react-dom': { singleton: true } }
    }),
    new HtmlWebpackPlugin({ template: './public/index.html' })
  ],
  devServer: { historyApiFallback: true, headers: { 'Access-Control-Allow-Origin': '*' } }
};
