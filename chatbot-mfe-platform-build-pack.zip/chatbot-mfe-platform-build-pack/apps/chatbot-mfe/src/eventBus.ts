import { CHATBOT_CONTEXT_CHANGED, ChatbotContextEvent, ChatbotContextEventSchema } from '@platform/contracts';

export function subscribeToChatbotContext(handler: (event: ChatbotContextEvent) => void) {
  const listener = (raw: Event) => {
    const detail = (raw as CustomEvent).detail;
    const parsed = ChatbotContextEventSchema.safeParse(detail);
    if (!parsed.success) {
      console.warn('Dropped invalid chatbot context event', parsed.error.flatten());
      return;
    }
    handler(parsed.data);
  };
  window.addEventListener(CHATBOT_CONTEXT_CHANGED, listener as EventListener);
  return () => window.removeEventListener(CHATBOT_CONTEXT_CHANGED, listener as EventListener);
}
