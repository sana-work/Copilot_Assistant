import React, { FormEvent, useMemo, useState } from 'react';
import { ChatbotContextProvider, useChatbotContext } from './context/ChatbotContextProvider';
import { streamChat } from './api/chatbotClient';

function ChatPanel() {
  const { activeContext } = useChatbotContext();
  const [open, setOpen] = useState(true);
  const [message, setMessage] = useState('Why did this record fail?');
  const [answer, setAnswer] = useState('');
  const [busy, setBusy] = useState(false);
  const conversationId = useMemo(() => crypto.randomUUID(), []);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setAnswer('');
    try {
      await streamChat({ message, conversationId, context: activeContext }, (evt) => {
        if (evt.event === 'token') setAnswer((prev) => prev + evt.data.text);
        if (evt.event === 'policy_block') setAnswer(`Policy block: ${evt.data.reason}`);
        if (evt.event === 'error') setAnswer(`Error: ${evt.data.message}`);
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <aside className="chatbot" aria-label="Citi Ops Assistant">
      <button className="chatbot-toggle" onClick={() => setOpen((v) => !v)} aria-expanded={open}>
        {open ? 'Close' : 'Open'} Chat
      </button>
      {open && (
        <section className="chatbot-panel">
          <h2>Citi Ops Assistant</h2>
          <p className="context-badge">
            Context: {activeContext ? `${activeContext.lob} / ${activeContext.contextId}` : 'No active record'}
          </p>
          <form onSubmit={submit}>
            <label htmlFor="chat-message">Ask about current context</label>
            <textarea id="chat-message" value={message} onChange={(e) => setMessage(e.target.value)} />
            <button type="submit" disabled={busy}>{busy ? 'Thinking...' : 'Send'}</button>
          </form>
          <div className="answer" aria-live="polite">{answer}</div>
        </section>
      )}
    </aside>
  );
}

export default function App() {
  return (
    <ChatbotContextProvider>
      <ChatPanel />
    </ChatbotContextProvider>
  );
}
