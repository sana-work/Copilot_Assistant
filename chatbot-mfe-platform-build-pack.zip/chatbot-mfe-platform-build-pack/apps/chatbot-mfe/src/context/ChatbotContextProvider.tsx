import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { ChatbotContextEvent } from '@platform/contracts';
import { subscribeToChatbotContext } from '../eventBus';

type ChatbotContextState = {
  activeContext?: ChatbotContextEvent;
  history: ChatbotContextEvent[];
};

const ChatbotContext = createContext<ChatbotContextState>({ history: [] });

export function ChatbotContextProvider({ children }: { children: React.ReactNode }) {
  const [history, setHistory] = useState<ChatbotContextEvent[]>([]);

  useEffect(() => {
    return subscribeToChatbotContext((event) => {
      const expiryMs = Date.now() + event.ttlSeconds * 1000;
      sessionStorage.setItem('chatbot.activeContext', JSON.stringify({ ...event, expiryMs }));
      setHistory((prev) => [event, ...prev].slice(0, 10));
    });
  }, []);

  const value = useMemo(() => ({ activeContext: history[0], history }), [history]);
  return <ChatbotContext.Provider value={value}>{children}</ChatbotContext.Provider>;
}

export function useChatbotContext() {
  return useContext(ChatbotContext);
}
