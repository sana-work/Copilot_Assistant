import { ChatMessageRequest, SseEvent } from '@platform/contracts';

export async function streamChat(
  payload: ChatMessageRequest,
  onEvent: (event: SseEvent) => void,
  signal?: AbortSignal
) {
  const response = await fetch('http://localhost:4000/api/chat/stream', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer dev-user-token',
      'X-Correlation-Id': crypto.randomUUID()
    },
    body: JSON.stringify(payload),
    signal
  });

  if (!response.ok || !response.body) throw new Error(`BFF returned ${response.status}`);

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const messages = buffer.split('\n\n');
    buffer = messages.pop() ?? '';
    for (const message of messages) {
      const eventLine = message.split('\n').find((line) => line.startsWith('event:'));
      const dataLine = message.split('\n').find((line) => line.startsWith('data:'));
      if (!eventLine || !dataLine) continue;
      const eventName = eventLine.replace('event:', '').trim();
      const data = JSON.parse(dataLine.replace('data:', '').trim());
      onEvent({ event: eventName, data } as SseEvent);
    }
  }
}
