import React, { Suspense, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const ChatbotApp = React.lazy(() => import('chatbotMfe/App'));
const PaymentsApp = React.lazy(() => import('paymentsMfe/App'));
const TradeApp = React.lazy(() => import('tradeMfe/App'));

function App() {
  const [tab, setTab] = useState<'payments' | 'trade'>('payments');
  return (
    <main className="shell">
      <header className="shell-header">
        <h1>Services Shared Ops UI Platform</h1>
        <p>Host Shell mounting business MFEs and ChatbotMFE as siblings</p>
      </header>
      <nav aria-label="Business applications">
        <button onClick={() => setTab('payments')} aria-pressed={tab === 'payments'}>Payments</button>
        <button onClick={() => setTab('trade')} aria-pressed={tab === 'trade'}>Trade</button>
      </nav>
      <section className="mfe-region">
        <Suspense fallback={<p>Loading business MFE...</p>}>
          {tab === 'payments' ? <PaymentsApp /> : <TradeApp />}
        </Suspense>
      </section>
      <Suspense fallback={null}>
        <ChatbotApp />
      </Suspense>
    </main>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
