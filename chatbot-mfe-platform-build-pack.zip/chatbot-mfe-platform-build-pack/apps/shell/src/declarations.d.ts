declare module 'chatbotMfe/App';
declare module 'paymentsMfe/App';
declare module 'tradeMfe/App';
