import React from 'react';
import { CHATBOT_CONTEXT_CHANGED, ChatbotContextEvent } from '@platform/contracts';

const payments = [
  { id: 'PAY-1001', status: 'Failed', amountBand: 'High', region: 'NA' },
  { id: 'PAY-1002', status: 'Pending Approval', amountBand: 'Medium', region: 'EMEA' },
  { id: 'PAY-9999', status: 'Restricted', amountBand: 'High', region: 'APAC' }
];

function publishPaymentContext(payment: (typeof payments)[number]) {
  const payload: ChatbotContextEvent = {
    eventVersion: '1.0',
    sourceMfe: 'PaymentsMFE',
    lob: 'Payments',
    contextType: 'payment_record_selected',
    contextId: payment.id,
    contextSummary: { status: payment.status, amountBand: payment.amountBand, region: payment.region },
    classification: payment.id === 'PAY-9999' ? 'restricted' : 'confidential',
    permissions: { canViewDetails: payment.id !== 'PAY-9999', canTriggerWorkflow: false },
    ttlSeconds: 900,
    timestamp: new Date().toISOString(),
    correlationId: crypto.randomUUID()
  };
  window.dispatchEvent(new CustomEvent(CHATBOT_CONTEXT_CHANGED, { detail: payload }));
}

export default function App() {
  return (
    <section>
      <h2>PaymentsMFE</h2>
      <p>Selecting a payment emits browser-only context. No backend call should happen.</p>
      {payments.map((payment) => (
        <button key={payment.id} onClick={() => publishPaymentContext(payment)} style={{ display: 'block', margin: '8px 0' }}>
          Select {payment.id} — {payment.status}
        </button>
      ))}
    </section>
  );
}
