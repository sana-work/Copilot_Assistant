import React from 'react';
import { CHATBOT_CONTEXT_CHANGED, ChatbotContextEvent } from '@platform/contracts';

const trades = [
  { id: 'TRD-2001', status: 'Settlement Failed', region: 'NA' },
  { id: 'TRD-2002', status: 'Open Position', region: 'EMEA' }
];

function publishTradeContext(trade: (typeof trades)[number]) {
  const payload: ChatbotContextEvent = {
    eventVersion: '1.0',
    sourceMfe: 'TradeMFE',
    lob: 'Trade',
    contextType: 'trade_record_selected',
    contextId: trade.id,
    contextSummary: { status: trade.status, region: trade.region },
    classification: 'confidential',
    permissions: { canViewDetails: true, canTriggerWorkflow: false },
    ttlSeconds: 900,
    timestamp: new Date().toISOString(),
    correlationId: crypto.randomUUID()
  };
  window.dispatchEvent(new CustomEvent(CHATBOT_CONTEXT_CHANGED, { detail: payload }));
}

export default function App() {
  return (
    <section>
      <h2>TradeMFE</h2>
      <p>Selecting a trade emits browser-only context. No backend call should happen.</p>
      {trades.map((trade) => (
        <button key={trade.id} onClick={() => publishTradeContext(trade)} style={{ display: 'block', margin: '8px 0' }}>
          Select {trade.id} — {trade.status}
        </button>
      ))}
    </section>
  );
}
