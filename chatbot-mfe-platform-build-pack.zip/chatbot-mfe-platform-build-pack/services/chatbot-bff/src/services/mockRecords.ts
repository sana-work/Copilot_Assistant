export const mockRecords: Record<string, Record<string, unknown>> = {
  'PAY-1001': {
    id: 'PAY-1001',
    status: 'Failed',
    failureReason: 'Beneficiary bank code mismatch',
    nextAction: 'Validate beneficiary bank code and retry payment',
    accountNumber: '1234567890',
    customerName: 'Example Customer',
    rawNotes: 'Internal note with sensitive operational details'
  },
  'PAY-1002': {
    id: 'PAY-1002',
    status: 'Pending Approval',
    nextAction: 'Manager approval required',
    accountNumber: '5555555555',
    customerName: 'Example Customer 2'
  },
  'TRD-2001': {
    id: 'TRD-2001',
    status: 'Settlement Failed',
    failureReason: 'Counterparty confirmation missing',
    nextAction: 'Request confirmation and reattempt settlement',
    customerName: 'Example Client'
  },
  'TRD-2002': {
    id: 'TRD-2002',
    status: 'Open Position',
    nextAction: 'Review exposure and settlement window'
  }
};
