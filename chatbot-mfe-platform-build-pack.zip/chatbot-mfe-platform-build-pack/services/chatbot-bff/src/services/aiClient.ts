import { User } from '../security/auth';

type Args = {
  message: string;
  safeContext?: Record<string, unknown>;
  user: User;
};

export async function* streamMockAiResponse({ message, safeContext }: Args): AsyncGenerator<string> {
  const answer = safeContext
    ? `Based on the current ${safeContext.lob} context (${safeContext.id}), status is ${safeContext.status}. ${safeContext.failureReason ? `Likely reason: ${safeContext.failureReason}. ` : ''}${safeContext.nextAction ? `Recommended next action: ${safeContext.nextAction}.` : ''}`
    : `I can help, but no active business record context is available. You asked: ${message}`;

  for (const word of answer.split(' ')) {
    await new Promise((resolve) => setTimeout(resolve, 35));
    yield `${word} `;
  }
}
