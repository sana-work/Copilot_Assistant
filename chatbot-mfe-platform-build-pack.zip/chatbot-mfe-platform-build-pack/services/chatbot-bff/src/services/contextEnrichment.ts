import { ChatbotContextEvent } from '@platform/contracts';
import { mockRecords } from './mockRecords';

export async function enrichContext(context: ChatbotContextEvent) {
  const record = mockRecords[context.contextId] ?? { id: context.contextId, status: 'Unknown' };
  return {
    ...record,
    lob: context.lob,
    sourceMfe: context.sourceMfe,
    classification: context.classification
  };
}
