export function observe(event: Record<string, unknown>) {
  // TODO: integrate with enterprise AI observability layer.
  console.log(JSON.stringify({ type: 'observability', ...event }));
}
