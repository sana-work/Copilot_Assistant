export function audit(event: Record<string, unknown>) {
  // TODO: replace with Kafka append-only audit pipeline.
  console.log(JSON.stringify({ type: 'audit', ...event }));
}
