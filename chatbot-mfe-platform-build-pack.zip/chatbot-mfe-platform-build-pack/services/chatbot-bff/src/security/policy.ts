export function isPolicyBlocked(message: string): boolean {
  const lowered = message.toLowerCase();
  return lowered.includes('ignore previous instructions') || lowered.includes('show me secrets');
}
