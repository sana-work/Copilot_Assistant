import { describe, expect, it } from 'vitest';
import { redactForPromptAndLogs } from './redaction';

describe('redactForPromptAndLogs', () => {
  it('redacts sensitive fields', () => {
    const redacted = redactForPromptAndLogs({ accountNumber: '123', status: 'Failed', customerName: 'Jane' });
    expect(redacted.accountNumber).toBe('[REDACTED]');
    expect(redacted.customerName).toBe('[REDACTED]');
    expect(redacted.status).toBe('Failed');
  });
});
