const SENSITIVE_KEYS = new Set(['accountNumber', 'customerName', 'taxId', 'address', 'rawNotes']);

export function redactForPromptAndLogs<T extends Record<string, unknown>>(input: T): T {
  const output: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input)) {
    if (SENSITIVE_KEYS.has(key)) output[key] = '[REDACTED]';
    else output[key] = value;
  }
  return output as T;
}
