import type { FastifyRequest } from 'fastify';

export type User = {
  id: string;
  roles: string[];
  lobs: string[];
  regions: string[];
};

export function getUserFromRequest(request: FastifyRequest): User {
  const auth = request.headers.authorization;
  if (!auth?.startsWith('Bearer ')) throw new Error('Missing authorization');
  return {
    id: 'dev-user-1',
    roles: ['ops-analyst'],
    lobs: ['Payments', 'Trade'],
    regions: ['NA', 'EMEA']
  };
}
