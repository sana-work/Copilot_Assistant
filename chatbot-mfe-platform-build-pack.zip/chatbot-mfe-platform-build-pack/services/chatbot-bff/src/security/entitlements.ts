import { ChatbotContextEvent } from '@platform/contracts';
import { User } from './auth';

export function isEntitledToContext(user: User, context: ChatbotContextEvent): boolean {
  if (!user.lobs.includes(context.lob)) return false;
  if (context.classification === 'restricted') return false;
  if (context.contextId.endsWith('9999')) return false;
  return true;
}
