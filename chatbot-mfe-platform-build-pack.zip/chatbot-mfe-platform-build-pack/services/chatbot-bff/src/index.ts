import Fastify from 'fastify';
import cors from '@fastify/cors';
import { ChatMessageRequestSchema } from '@platform/contracts';
import { getUserFromRequest } from './security/auth';
import { isEntitledToContext } from './security/entitlements';
import { enrichContext } from './services/contextEnrichment';
import { redactForPromptAndLogs } from './security/redaction';
import { isPolicyBlocked } from './security/policy';
import { streamMockAiResponse } from './services/aiClient';
import { audit } from './services/audit';
import { observe } from './services/observability';

const app = Fastify({ logger: true });
await app.register(cors, { origin: true });

app.get('/health', async () => ({ ok: true, service: 'chatbot-bff' }));

app.post('/api/chat/stream', async (request, reply) => {
  const correlationId = String(request.headers['x-correlation-id'] ?? crypto.randomUUID());
  const started = Date.now();

  reply.raw.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Correlation-Id': correlationId
  });

  const send = (event: string, data: unknown) => {
    reply.raw.write(`event: ${event}\n`);
    reply.raw.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    const user = getUserFromRequest(request);
    const parsed = ChatMessageRequestSchema.safeParse(request.body);
    if (!parsed.success) {
      send('error', { message: 'Invalid chat request' });
      send('done', { finishReason: 'error' });
      return reply.raw.end();
    }

    const { message, conversationId, context } = parsed.data;
    send('metadata', { correlationId, conversationId });

    if (isPolicyBlocked(message)) {
      audit({ correlationId, event: 'policy_block', userId: user.id, reason: 'unsafe_input' });
      send('policy_block', { reason: 'Your request could not be processed because it violates policy.' });
      send('done', { finishReason: 'blocked' });
      return reply.raw.end();
    }

    if (context && !isEntitledToContext(user, context)) {
      audit({ correlationId, event: 'entitlement_denied', userId: user.id, contextId: context.contextId });
      send('token', { text: 'You do not have permission to view details for this record.' });
      send('done', { finishReason: 'stop' });
      return reply.raw.end();
    }

    const fullContext = context ? await enrichContext(context) : undefined;
    const safeContext = fullContext ? redactForPromptAndLogs(fullContext) : undefined;

    audit({ correlationId, event: 'chat_started', userId: user.id, lob: context?.lob, contextId: context?.contextId });

    for await (const token of streamMockAiResponse({ message, safeContext, user })) {
      send('token', { text: token });
    }

    observe({ correlationId, event: 'chat_completed', latencyMs: Date.now() - started, lob: context?.lob });
    send('done', { finishReason: 'stop' });
    return reply.raw.end();
  } catch (err) {
    request.log.error({ err, correlationId }, 'chat stream failed');
    send('error', { message: 'The assistant is temporarily unavailable. Please try again.' });
    send('done', { finishReason: 'error' });
    return reply.raw.end();
  }
});

app.get('/api/config/:lob', async (request) => {
  const { lob } = request.params as { lob: string };
  return {
    lob,
    personaName: lob === 'Payments' ? 'PayBot' : lob === 'Trade' ? 'TradeAssist' : 'Citi Ops Assistant',
    allowedFeatures: ['chat', 'context', 'sse'],
    locked: ['auth', 'audit', 'redaction', 'entitlement', 'bff-protocol']
  };
});

const port = Number(process.env.BFF_PORT ?? 4000);
await app.listen({ port, host: '0.0.0.0' });
