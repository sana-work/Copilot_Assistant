# Architecture Decisions

## ADR-001: Chatbot as shell-mounted platform MFE

Decision: ChatbotMFE is mounted once by the Host Shell and operates as a sibling to business MFEs.

Rationale:
- independent deployment
- persistent conversation across navigation
- central ownership and governance
- avoids version fragmentation across LOBs
- enables governed extension model

Rejected:
- embedding a shared chatbot component separately in every LOB MFE

## ADR-002: Navigation context is passive

Decision: Business MFEs emit browser events for navigation/context changes. These events update ChatbotMFE local context only. They do not call BFF or AI by default.

Rationale:
- separates navigation from chat intent
- avoids unnecessary token cost
- avoids backend load during normal navigation
- preserves privacy by sending only safe references/summaries

## ADR-003: BFF is mandatory gateway

Decision: ChatbotMFE calls only Chatbot BFF. BFF calls AI platform and business APIs.

Rationale:
- secrets never reach browser
- entitlement enforced server-side
- prompt enrichment and redaction controlled centrally
- audit and observability consistent

## ADR-004: Governed LOB extensibility

Decision: LOBs customize through config, approved UI slots, approved tools, lifecycle hooks, and workflow triggers.

Locked central behaviors:
- auth/session
- audit logging
- redaction
- rate limiting
- prompt safety
- entitlement checks
- model invocation
- BFF protocol
