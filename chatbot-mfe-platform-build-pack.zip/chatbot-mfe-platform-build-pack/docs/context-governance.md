# Context Governance

## Frontend context may contain

- LOB name
- source MFE
- record type
- record ID/reference
- safe status summary
- classification
- permission snapshot
- timestamp
- TTL
- correlation ID

## Frontend context must not contain

- full customer names
- full account numbers
- addresses
- raw comments or notes
- tax IDs or national IDs
- full payment/trade payloads
- documents
- secrets or credentials

## BFF enrichment

BFF fetches full record server-side only after entitlement validation.

## Domain switch behavior

When switching between LOBs, keep conversation but mark previous domain context as historical. Expire active context after TTL or if classification changes.
