# Event Contract — CHATBOT_CONTEXT_CHANGED

## Purpose

Business MFEs publish safe context updates when the user navigates or selects records. ChatbotMFE listens and updates in-memory/session context.

## Event name

```ts
CHATBOT_CONTEXT_CHANGED
```

## Rules

- Event is browser-only and fire-and-forget.
- Event must not trigger BFF or AI call.
- Payload must contain safe reference/summary only.
- No raw PII, account numbers, names, comments, documents, or credentials.
- Payload must include version, sourceMfe, lob, contextType, contextId, classification, timestamp, ttlSeconds, and correlationId.
- Consumer must validate schema and drop invalid/stale events.

## Example payload

```json
{
  "eventVersion": "1.0",
  "sourceMfe": "PaymentsMFE",
  "lob": "Payments",
  "contextType": "payment_record_selected",
  "contextId": "PAY-1001",
  "contextSummary": {
    "status": "Failed",
    "amountBand": "High",
    "region": "NA"
  },
  "classification": "confidential",
  "permissions": {
    "canViewDetails": true,
    "canTriggerWorkflow": false
  },
  "ttlSeconds": 900,
  "timestamp": "2026-05-20T12:00:00.000Z",
  "correlationId": "ctx_abc123"
}
```
