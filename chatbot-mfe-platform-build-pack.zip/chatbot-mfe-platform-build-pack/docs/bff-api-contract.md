# BFF API Contract

## POST /api/chat/stream

Streams chatbot answer over SSE.

Request:

```json
{
  "message": "Why did this payment fail?",
  "conversationId": "conv_123",
  "context": {
    "eventVersion": "1.0",
    "sourceMfe": "PaymentsMFE",
    "lob": "Payments",
    "contextType": "payment_record_selected",
    "contextId": "PAY-1001",
    "classification": "confidential"
  }
}
```

Headers:

```text
Authorization: Bearer dev-user-token
X-Correlation-Id: req_abc123
```

SSE events:

```text
event: metadata
data: {"correlationId":"req_abc123","conversationId":"conv_123"}

event: token
data: {"text":"This payment "}

event: done
data: {"finishReason":"stop"}
```

## Server-side rules

1. Validate user.
2. Validate payload.
3. Check record-level entitlement.
4. Fetch full record from mock business API.
5. Redact sensitive fields.
6. Build safe prompt.
7. Apply policy checks.
8. Bypass cache if sensitive/record-specific.
9. Stream response.
10. Audit without raw PII.
