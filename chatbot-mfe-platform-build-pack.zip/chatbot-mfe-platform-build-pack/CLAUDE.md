# CLAUDE.md — Project Instructions for Claude Code

## Mission

Build an enterprise-grade Chatbot MFE platform based on the architecture deck:

- React + TypeScript + Webpack 5 Module Federation for frontend MFEs
- Host Shell mounts ChatbotMFE once and business MFEs as siblings
- Business MFEs emit browser events for passive context changes
- ChatbotMFE stores safe context only and never calls AI directly
- Node.js/Fastify BFF provides secure gateway, SSE streaming, mock AI orchestration, entitlement checks, redaction, audit logging, and observability
- LOB customization uses governed config and approved extension/plugin contracts

## Non-negotiable architecture rules

1. ChatbotMFE is mounted once by Host Shell. Do not embed a separate chatbot inside each LOB MFE.
2. Business MFEs communicate with ChatbotMFE through a typed event contract, not props.
3. Navigation/context changes must not call the backend or AI platform by default.
4. Only explicit user chat submission calls the BFF.
5. Browser stores safe context references/summaries only. No full business records, PII, secrets, or credentials in frontend state.
6. All AI/business/backend calls go through the BFF. Frontend must never call AI platform directly.
7. BFF must validate user identity and record-level entitlement before enrichment or tool execution.
8. BFF must redact sensitive fields before prompt construction, logging, and streaming output.
9. LOBs may customize through config/plugins/tools/hooks only. They cannot override locked behaviors: auth, audit, PII redaction, prompt safety, rate limiting, entitlement, BFF protocol, or model invocation policy.
10. Every chat request must include correlation ID, conversation ID, source MFE, LOB, and data classification.

## Build conventions

- Use TypeScript everywhere.
- Keep contracts in `packages/contracts` and import from there.
- Validate event payloads and API payloads with Zod.
- Keep UI simple, accessible, and enterprise-friendly.
- Use SSE for token streaming from BFF to ChatbotMFE.
- Use in-memory mocks for AI platform, business APIs, and Kafka initially.
- Add TODO markers for real enterprise integration points.

## Required apps/packages

- `apps/shell` — host shell with Module Federation remotes
- `apps/chatbot-mfe` — floating chatbot MFE
- `apps/payments-mfe` — demo LOB MFE emitting payment context events
- `apps/trade-mfe` — demo LOB MFE emitting trade context events
- `services/chatbot-bff` — secure BFF gateway
- `packages/contracts` — shared event/API schemas
- `packages/ui` — optional shared UI primitives

## Validation commands

Run these before marking work complete:

```bash
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

For manual testing:

```bash
pnpm dev
```

Then verify:

- Navigating records updates chatbot context without network call to BFF.
- Sending chat calls `/api/chat/stream` once.
- Unauthorized record returns access denied.
- BFF redacts sensitive fields in logs and responses.
- SSE streaming shows progressive output.
- Shell continues working if ChatbotMFE fails to load.

## Security review checklist

- No API key, AI credential, or secret in frontend code.
- No full account numbers, customer names, or sensitive details stored in browser context.
- No raw prompt logs containing PII.
- Tool calls require entitlement checks.
- Workflow/action triggers require confirmation.
- Cache bypasses sensitive or user-specific requests.
- Errors are user-friendly and do not leak stack traces.

## Preferred implementation approach

Start with contracts, then BFF API, then frontend event handling, then UI, then tests.

Use subagents where helpful:

- frontend-architect for React/MFE/event bus work
- bff-architect for Fastify/SSE/security gateway work
- security-reviewer for guardrails, redaction, entitlement, restricted content
- qa-reviewer for test cases and manual verification
