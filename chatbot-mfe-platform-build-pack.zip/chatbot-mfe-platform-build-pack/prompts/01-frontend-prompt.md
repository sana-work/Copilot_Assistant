# Frontend Build Prompt

Implement the React + TypeScript frontend using Webpack 5 Module Federation.

## Apps

- `apps/shell`
- `apps/chatbot-mfe`
- `apps/payments-mfe`
- `apps/trade-mfe`

## Requirements

1. Shell mounts all remotes as siblings.
2. ChatbotMFE is mounted once and floats above all LOB MFEs.
3. PaymentsMFE and TradeMFE emit `CHATBOT_CONTEXT_CHANGED` on record selection.
4. ChatbotMFE passively listens to the event and stores context in memory/sessionStorage.
5. ChatbotMFE calls BFF only when user sends a chat message.
6. API client uses SSE and renders token-by-token streaming response.
7. Add accessible keyboard support for open/close, send, and focus management.
8. Add UI slots for LOB-provided actions like “View in Payments” or “Create JIRA ticket.”

## Files to prioritize

- `packages/contracts/src/events.ts`
- `apps/chatbot-mfe/src/context/ChatbotContextProvider.tsx`
- `apps/chatbot-mfe/src/eventBus.ts`
- `apps/chatbot-mfe/src/api/chatbotClient.ts`
- `apps/chatbot-mfe/src/App.tsx`
- `apps/payments-mfe/src/App.tsx`
- `apps/trade-mfe/src/App.tsx`
- `apps/shell/src/App.tsx`
