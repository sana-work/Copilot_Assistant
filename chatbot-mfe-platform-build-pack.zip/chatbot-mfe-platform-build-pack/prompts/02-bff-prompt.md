# BFF Build Prompt

Implement `services/chatbot-bff` as the secure backend gateway.

## Required endpoints

- `GET /health`
- `POST /api/chat/stream` with SSE response
- `GET /api/config/:lob`
- `POST /api/audit`

## Required modules

- `auth.ts` — mock user identity and auth token validation
- `entitlements.ts` — record-level access checks
- `redaction.ts` — remove/mask sensitive fields before logging and prompting
- `contextEnrichment.ts` — fetch full mock record from business API based on safe frontend context
- `promptBuilder.ts` — create safe prompt from message + redacted context
- `aiClient.ts` — mock AI streaming response; TODO real AI platform client
- `cache.ts` — semantic cache with strict bypass for sensitive/user-specific queries
- `observability.ts` — correlation ID, latency, token count, safety events
- `routes/chat.ts` — SSE streaming route

## Security rules

- Reject requests without user identity.
- Check entitlement before fetching or using full business data.
- Never log raw PII.
- Never cache sensitive or record-specific responses by default.
- Include correlation ID in every log and response.
- Simulate policy block for prompt injection-like input.
