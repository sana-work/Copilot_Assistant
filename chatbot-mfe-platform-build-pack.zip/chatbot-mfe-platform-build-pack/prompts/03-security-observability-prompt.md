# Security and Observability Hardening Prompt

Review and improve the application for enterprise readiness.

## Security review

Check:

- Frontend has no secrets or direct AI calls.
- Browser context contains only safe references and summaries.
- Event schema has allowlisted fields and classification.
- BFF validates entitlement before enrichment and tool execution.
- Redaction happens before prompt construction and audit logging.
- Cache bypasses sensitive, user-specific, or record-specific queries.
- Errors do not leak internals.

## Observability review

Add or verify:

- correlationId
- conversationId
- messageId
- sourceMfe
- lob
- intent
- model name/mock model
- latencyMs
- token count
- policy decisions
- redaction events
- entitlement result
- cache hit/miss/bypass
- tool calls
- user feedback placeholder

## Output

Return:

- risks found
- files changed
- test evidence
- production hardening backlog
