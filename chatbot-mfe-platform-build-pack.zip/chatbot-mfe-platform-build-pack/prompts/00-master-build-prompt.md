# Claude Code Master Build Prompt

Use the architecture in `CLAUDE.md` and implement the complete starter application.

## Goal

Generate a working enterprise Chatbot MFE platform with:

- Host Shell
- ChatbotMFE
- PaymentsMFE
- TradeMFE
- Chatbot BFF
- Shared contracts
- Event-driven navigation context
- SSE chat streaming
- Mock entitlement, redaction, observability, caching, and AI response

## Required implementation order

1. Inspect repo structure and current files.
2. Create/fix package workspace configuration.
3. Implement `packages/contracts` first.
4. Implement BFF with Fastify.
5. Implement ChatbotMFE with context provider, event listener, BFF client, and UI.
6. Implement PaymentsMFE and TradeMFE demo events.
7. Implement Shell with Module Federation remotes and resilient loading.
8. Add tests for contracts, entitlement, redaction, and event handling.
9. Run lint, typecheck, test, build.
10. Produce a short architecture summary and list of follow-up production hardening tasks.

## Acceptance criteria

- `pnpm dev` starts all apps and service.
- Shell displays Payments and Trade demo areas plus floating chatbot.
- Selecting a payment/trade emits `CHATBOT_CONTEXT_CHANGED` and updates chatbot context badge silently.
- Chat submit calls BFF and streams response over SSE.
- Unauthorized record ID returns safe access-denied response.
- BFF logs correlation ID and redacts sensitive data.
- Contracts are shared between frontend and backend.
- No direct AI call exists in frontend.

## Challenge points to preserve

- Navigation != chat intent.
- Safe context != full data.
- LOB config/plugin != core code override.
- BFF gateway is mandatory.
