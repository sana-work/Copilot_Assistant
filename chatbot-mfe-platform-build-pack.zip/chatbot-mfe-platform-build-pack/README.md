# Chatbot MFE Platform Starter — Claude Code Build Pack

This repository is a starter scaffold for the architecture discussed in the deck:

- Host Shell mounts business MFEs and ChatbotMFE once
- Business MFEs publish passive context events on navigation
- ChatbotMFE stores safe context and calls BFF only on explicit user chat
- Chatbot BFF performs auth, entitlement, redaction, policy, caching, observability, and streaming response
- LOB customization happens through governed config and plugin/tool registration

## Recommended build sequence with Claude Code

1. Install dependencies and initialize repo.
2. Run Claude Code from the repo root.
3. Run `/init`, then replace or merge the generated `CLAUDE.md` with the supplied one.
4. Run `/permissions` and allow only safe project commands.
5. Run `/plan` using `prompts/00-master-build-prompt.md`.
6. Use `/batch` or subagents to build frontend, backend, security, and tests in parallel.
7. Run `/run-skill-generator` once the apps are in place.
8. Use `/verify` and `/security-review` before committing.

## Local setup

```bash
corepack enable
pnpm install
pnpm dev
```

Expected ports:

- Host Shell: http://localhost:3000
- Chatbot MFE: http://localhost:3001
- Payments MFE: http://localhost:3002
- Trade MFE: http://localhost:3003
- Chatbot BFF: http://localhost:4000

## Demo behavior

1. Open the host shell.
2. Navigate to Payments and select a payment.
3. Payments MFE emits `CHATBOT_CONTEXT_CHANGED`.
4. ChatbotMFE updates context silently. No BFF call happens.
5. Type “Why did this payment fail?” in chatbot.
6. ChatbotMFE calls BFF with message + accumulated context.
7. BFF checks entitlement, enriches data, redacts sensitive info, and streams response.

## Important architecture rule

Navigation is passive. Chat is explicit intent.

```text
Navigation event -> browser context update only -> no AI call
Chat message -> BFF -> AI/orchestration -> streaming response
```
