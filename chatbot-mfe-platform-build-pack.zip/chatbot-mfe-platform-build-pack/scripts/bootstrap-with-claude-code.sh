#!/usr/bin/env bash
set -euo pipefail

corepack enable
pnpm install

echo "Now run: claude"
echo "Inside Claude Code, run: /init, /permissions, /plan"
echo "Then paste prompts/00-master-build-prompt.md"
